# Kaze UI Library Handoff

## Overview
Static visual reference showcasing available UI components from the Kaze UI Library. This gallery displays component groups, intended usage, and visual variants for screen generation.

## Screenshots
- `screenshots/KazeComponentGallery_Default_Desktop.png`
  - State: `Default`
  - Viewport: `Desktop`

## Visible Layout
- Grid layout containing component cards: Typography, Buttons, Avatar + Badge, Inputs, Selection, Segmented + Slider, Labels, Progress + Steps, Navigation, Feedback, Upload, Collapse + Context, Tables, Utility Exports.
- Dark themed background. Follow Kaze/project tokens.
- Approximate visual estimate: Consistent padding and spacing between component groups.

## Main Actions
- Review component groups.
- Compare visual component examples.
- Identify matching Kaze exports for screenshot-to-code generation.
- Verify utility exports such as `notification` and `useNotification`.

## Visual Notes
- Light theme with blue primary action color.
- Rounded corners on inputs, buttons, and cards.
- Icons: Use existing project icon pattern or inline SVG fallback. No confirmed Kaze "Icon" export.

## Required States
- Default: Shown for all components.
- Input focused: Likely standard Kaze behaviour.
- Input with text: Likely supported for TextField/TextArea.
- Processing/loading: TODO unless confirmed by interaction.
- Error: TODO unless submit action confirmed.
- Disabled: TODO unless required.

## Unknowns
- Exact interactive behavior for sample components is not confirmed.
- Component props and variants should be verified against installed Kaze package typings or Storybook.
- Layout wrappers/cards are not confirmed Kaze exports unless package typings prove they exist.
- Utility exports such as `notification` and `useNotification` should only be used when notification behavior is required.