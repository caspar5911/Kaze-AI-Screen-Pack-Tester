import fs from "node:fs";
import path from "node:path";

const root = process.cwd();

const requiredFiles = [
  "README_FOR_CLINE.md",
  "pack-manifest.md",
  "handoff.md",
  "kaze-component-mapping.md",
  "cline-implementation-prompt.md",
  "qa-checklist.md",
  "validate-pack.mjs",
  "cline-readiness-standard.md",
  "screenshots/KazeComponentGallery_Default_Desktop.png"
];
const markdownFiles = requiredFiles.filter((file) => file.endsWith(".md"));
const contradictionPatterns = [
  /Forbidden\s+(?:Prefixed\s+)?Names:\s*.*`?\b(?:Button|TextField|Dropdown|Avatar|Typography)\b`?/i,
  /fake Kaze-prefixed components such as\s+`?\b(?:Button|TextField|Dropdown|Avatar|Typography)\b`?/i,
  /Does not use fake Kaze-prefixed components such as\s+`?\b(?:Button|TextField|Dropdown|Avatar|Typography)\b`?/i,
  /Does not import\s+`?\b(?:Button|TextField|Dropdown|Avatar|Typography)\b`?/i,
  /`?\b(?:Button|TextField|Dropdown|Avatar|Typography)\b`?\s+(?:is|are)\s+(?:fake|invalid|wrong|forbidden)/i,
  /(?:fake|invalid|wrong|forbidden)\s+(?:Kaze\s+)?(?:exports?|names?|components?)\s*[:\-][^\n]*\b(?:Button|TextField|Dropdown|Avatar|Typography)\b/i,
  /(?:\*\*)?(?:Wrong|Incorrect):(?:\*\*)?\s*`?import\s*{[^}]*\b(?:Button|TextField|Dropdown|Avatar|Typography)\b[^}]*}/i,
  /Invalid:\s*Do not use fake prefixed names like\s*`?\b(?:Button|TextField|Dropdown|Avatar|Typography)\b`?/i,
];
const fakeKazeImportPattern =
  /import\s*{\s*[^}]*\b(?:KazeButton|KazeInput|KazeSelect|KazeAvatar|KazeTypography)\b[^}]*}\s*from\s*["']@pcs-security\/kaze-ui-library["']/i;
const wrongMarkerPattern =
  /WRONG|Incorrect|do not use|fake Kaze-prefixed|invalid|do not import/i;
const galleryLeakPatterns = [
  /Enterprise AI Assistant/i,
  /Project\s*\/\s*feature screen/i,
  /Screen type/i,
  /Additional notes/i,
  /Fast Mode/i,
  /On-prem/i,
  /Screen Pack Generator/i,
];
const iconInternalRows = [
  /Arrow Down \(Dropdown\)/i,
  /Checkmark \(Checkbox\)/i,
  /Radio Circle \(Radio\)/i,
  /Toggle Knob/i,
  /Navigation Arrows/i,
];
const badUnknownExportPattern =
  /confirmed\s+[\x60]?Unknown \/ verify from Kaze[\x60]?\s+export|no confirmed\s+[\x60]?Unknown \/ verify from Kaze[\x60]?\s+export/i;
const weakCoveragePattern =
  /Visual Kaze exports visible or expected[\s\S]*-\s*[\x60]?Pills[\x60]?/i;

const forbiddenPatterns = [
  {
    file: "kaze-component-mapping.md",
    pattern: /Invalid:\s*Do not use fake prefixed names like\s*`?Button`?,\s*`?TextField`?,\s*`?Avatar`?/i,
    message: "Button/TextField/Avatar must not be described as fake invalid names.",
  },
  {
    file: "kaze-component-mapping.md",
    pattern: /(Forbidden Names|Forbidden Exports|Invalid)[^\n]*(Do\s+NOT\s+use|Do\s+not\s+use|Never\s+use)[^\n]*`?Button`?[^\n]*`?TextField`?[^\n]*(`?Dropdown`?|`?Avatar`?|`?Typography`?)/i,
    message: "Real Kaze exports such as Button, TextField, Dropdown, Avatar, and Typography must not be listed as forbidden.",
  },
  {
    file: "kaze-component-mapping.md",
    pattern: /import\s*{\s*KazeButton/i,
    message: "Fake Kaze-prefixed import must not appear unless clearly marked as WRONG.",
    allowIfAlsoMatches: /WRONG|Incorrect|do not use fake/i,
  },
];

const requiredTextChecks = [
  ...[
  {
    "file": "pack-manifest.md",
    "text": "screenshots/KazeComponentGallery_Default_Desktop.png",
    "message": "Manifest must reference screenshots/KazeComponentGallery_Default_Desktop.png."
  }
],
  {
    file: "pack-manifest.md",
    text: "README_FOR_CLINE.md",
    message: "Manifest must reference README_FOR_CLINE.md.",
  },
  {
    file: "pack-manifest.md",
    text: "validate-pack.mjs",
    message: "Manifest must reference validate-pack.mjs.",
  },
  {
    file: "pack-manifest.md",
    text: "cline-readiness-standard.md",
    message: "Manifest must reference cline-readiness-standard.md.",
  },
  {
    file: "cline-implementation-prompt.md",
    text: "Placement Rule",
    message: "Implementation prompt must include Placement Rule.",
  },
  {
    file: "cline-implementation-prompt.md",
    text: "Screenshot Usage Rule",
    message: "Implementation prompt must include Screenshot Usage Rule.",
  },
  {
    file: "cline-implementation-prompt.md",
    text: "Anti-Hallucination Rules",
    message: "Implementation prompt must include Anti-Hallucination Rules.",
  },
  {
    file: "cline-implementation-prompt.md",
    text: "Kaze Setup Rule",
    message: "Implementation prompt must include Kaze Setup Rule.",
  },
  {
    file: "kaze-component-mapping.md",
    text: "Import Rule",
    message: "Mapping must include Import Rule.",
  },
  {
    file: "kaze-component-mapping.md",
    text: "KazeButton",
    message: "Mapping must explicitly warn against fake Kaze-prefixed names.",
  },
  {
    file: "qa-checklist.md",
    text: "Kaze Usage",
    message: "QA checklist must include Kaze Usage section.",
  },
  {
    file: "qa-checklist.md",
    text: "Visual",
    message: "QA checklist must include Visual section.",
  },
  {
    file: "qa-checklist.md",
    text: "Implementation Safety",
    message: "QA checklist must include Implementation Safety section.",
  },
];

const errors = [];

for (const file of requiredFiles) {
  const fullPath = path.join(root, file);
  if (!fs.existsSync(fullPath)) {
    errors.push(`Missing required file: ${file}`);
  }
}

for (const check of requiredTextChecks) {
  const fullPath = path.join(root, check.file);
  if (!fs.existsSync(fullPath)) continue;

  const content = fs.readFileSync(fullPath, "utf8");
  if (!content.includes(check.text)) {
    errors.push(check.message);
  }
}

for (const check of forbiddenPatterns) {
  const fullPath = path.join(root, check.file);
  if (!fs.existsSync(fullPath)) continue;

  const content = fs.readFileSync(fullPath, "utf8");
  const hasForbidden = check.pattern.test(content);
  const allowed =
    check.allowIfAlsoMatches && check.allowIfAlsoMatches.test(content);

  if (hasForbidden && !allowed) {
    errors.push(check.message);
  }
}

for (const markdownFile of markdownFiles) {
  const fullPath = path.join(root, markdownFile);
  if (!fs.existsSync(fullPath)) continue;

  const content = fs.readFileSync(fullPath, "utf8");

  for (const pattern of contradictionPatterns) {
    if (pattern.test(content)) {
      errors.push(
        `${markdownFile}: Real Kaze exports must not be described as fake, invalid, wrong, or forbidden.`
      );
      break;
    }
  }

  const fakeImportIndex = content.search(fakeKazeImportPattern);
  if (fakeImportIndex >= 0) {
    const contextWindow = content.slice(
      Math.max(0, fakeImportIndex - 300),
      fakeImportIndex + 500
    );

    if (!wrongMarkerPattern.test(contextWindow)) {
      errors.push(
        `${markdownFile}: Fake Kaze-prefixed import appears without being clearly marked as wrong.`
      );
    }
  }
}

const manifestContent = fs.existsSync(path.join(root, "pack-manifest.md"))
  ? fs.readFileSync(path.join(root, "pack-manifest.md"), "utf8")
  : "";
const mappingContent = fs.existsSync(path.join(root, "kaze-component-mapping.md"))
  ? fs.readFileSync(path.join(root, "kaze-component-mapping.md"), "utf8")
  : "";
const isComponentGalleryPack =
  /Kaze Component Gallery|Kaze UI Components Gallery|UI Components Gallery|KazeComponentGallery/i.test(
    `${manifestContent}\n${mappingContent}`
  );

if (isComponentGalleryPack && mappingContent) {
  for (const pattern of galleryLeakPatterns) {
    if (pattern.test(mappingContent)) {
      errors.push(
        "kaze-component-mapping.md contains component gallery template leakage."
      );
      break;
    }
  }

  for (const pattern of iconInternalRows) {
    if (pattern.test(mappingContent)) {
      errors.push(
        "kaze-component-mapping.md maps icon internals as component rows."
      );
      break;
    }
  }

  if (badUnknownExportPattern.test(mappingContent)) {
    errors.push(
      "kaze-component-mapping.md treats Unknown / verify from Kaze as an export instead of a fallback label."
    );
  }

  if (weakCoveragePattern.test(mappingContent)) {
    errors.push(
      "kaze-component-mapping.md contains weak component gallery coverage instead of the deterministic coverage section."
    );
  }
}

if (errors.length > 0) {
  console.error("Pack validation failed:");
  for (const error of errors) {
    console.error(`- ${error}`);
  }
  process.exit(1);
}

console.log("Pack validation passed. This pack is Cline-ready.");
